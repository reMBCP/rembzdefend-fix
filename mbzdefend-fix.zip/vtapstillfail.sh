#!/system/bin/sh
echo "VTAP provision failed! Cannot continue!"
echo "If you have low-end device (eg : Vsmart Joy 2+)"
echo "Try to reinstall module again 3 more times."
exit 100 
