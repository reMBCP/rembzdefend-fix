#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done

for library in $(find /data/app -name libZDefend.so) ; do busybox sed -i 's|.zimperium|.123456789|g' $library ; done